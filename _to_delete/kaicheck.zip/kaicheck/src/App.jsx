import { useState } from 'react';
import Board from './components/Board.jsx';
import Children from './components/Children.jsx';
import Dishes from './components/Dishes.jsx';
import Header from './components/Header.jsx';
import ModalHost from './components/Modals.jsx';
import Planner from './components/Planner.jsx';
import Today from './components/Today.jsx';
import { TODAY } from './data';
import { useStore } from './store.jsx';

export default function App() {
  const { actions } = useStore();
  const [view, setViewRaw] = useState('today');
  const [day, setDay] = useState(TODAY);
  const [modal, setModal] = useState(null);

  const setView = (v) => {
    setViewRaw(v);
    setModal(null);
    window.scrollTo(0, 0);
  };

  return (
    <>
      <Header view={view} setView={setView} />
      <main>
        {view === 'today' && <Today day={day} setDay={setDay} setView={setView} openModal={setModal} />}
        {view === 'planner' && <Planner openModal={setModal} />}
        {view === 'children' && <Children openModal={setModal} />}
        {view === 'dishes' && <Dishes openModal={setModal} />}
        {view === 'board' && <Board />}
      </main>
      <div className="foot">
        Data is saved in this browser only. There is no backend yet.{' '}
        <button className="btn small" onClick={actions.reset}>
          Reset sample data
        </button>
      </div>
      <ModalHost modal={modal} setModal={setModal} />
    </>
  );
}
