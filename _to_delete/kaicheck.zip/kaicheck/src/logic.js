import { SLOTS } from './data';

export const getDish = (dishes, id) => dishes.find((d) => d.id === id);
export const getChild = (children, id) => children.find((c) => c.id === id);

/**
 * Children whose allergies overlap a dish's allergens.
 * A dish that has not been checked returns no clashes; callers must show it as "unchecked", never "safe".
 */
export function dishClashes(dish, children) {
  if (!dish || !dish.checked) return [];
  const out = [];
  for (const child of children) {
    const hit = child.allergies.filter((al) => dish.allergens.includes(al.a));
    if (hit.length) out.push({ child, hit, sev: hit.some((h) => h.sev === 'ana') ? 'ana' : 'int' });
  }
  return out.sort((a, b) => (a.sev === 'ana' ? 0 : 1) - (b.sev === 'ana' ? 0 : 1));
}

export const ackKey = (di, slotId, dishId, childId) => `${di}|${slotId}|${dishId}|${childId}`;

/** Everything that stops the week being published. */
export function planBlockers(state) {
  const { menu, dishes, children, acks } = state;
  const unchecked = [];
  const ana = [];
  const seen = new Set();
  menu.forEach((day, di) =>
    SLOTS.forEach((slot) =>
      day[slot.id].forEach((id) => {
        const dish = getDish(dishes, id);
        if (!dish) return;
        if (!dish.checked && !seen.has(id)) {
          seen.add(id);
          unchecked.push(dish);
        }
        dishClashes(dish, children).forEach((x) => {
          if (x.sev === 'ana') ana.push({ di, slot, dish, x, key: ackKey(di, slot.id, id, x.child.id) });
        });
      }),
    ),
  );
  const open = ana.filter((a) => !acks.includes(a.key));
  return { unchecked, ana, open, count: unchecked.length + open.length };
}

export function dishUsage(menu, dishId) {
  return menu.reduce((n, day) => n + SLOTS.reduce((m, s) => m + day[s.id].filter((x) => x === dishId).length, 0), 0);
}

export const can = {
  plan: (role) => role !== 'teacher',
  ack: (role) => role !== 'teacher',
  dishes: (role) => role !== 'teacher',
  kids: (role) => role === 'manager',
};
