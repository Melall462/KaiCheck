import { createContext, useCallback, useContext, useEffect, useMemo, useReducer, useRef, useState } from 'react';
import { seed } from './data';

/*
 * All reads and writes go through this file. When a backend arrives (Supabase),
 * replace the reducer + localStorage with queries and mutations here and the
 * components will not need to change.
 */

const KEY = 'kaicheck:v1';

const initial = () => ({ ...structuredClone(seed), acks: [], published: false, pubBy: '', role: 'manager' });

function load() {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const s = JSON.parse(raw);
      if (s && Array.isArray(s.children) && Array.isArray(s.dishes) && Array.isArray(s.menu) && Array.isArray(s.acks)) return s;
    }
  } catch {
    /* storage unavailable or corrupt: start from sample data */
  }
  return initial();
}

function reducer(state, a) {
  switch (a.type) {
    case 'SET_ROLE':
      return { ...state, role: a.role };
    case 'SAVE_CHILD': {
      const children = a.id
        ? state.children.map((c) => (c.id === a.id ? { ...c, ...a.rec } : c))
        : [...state.children, { id: 'c' + Date.now(), ...a.rec }];
      return { ...state, children, published: false };
    }
    case 'SAVE_DISH': {
      const dishes = a.id
        ? state.dishes.map((d) => (d.id === a.id ? { ...d, ...a.rec } : d))
        : [...state.dishes, { id: 'd' + Date.now(), ...a.rec }];
      return { ...state, dishes, published: false };
    }
    case 'ADD_TO_MENU': {
      const menu = state.menu.map((day, i) => (i === a.di ? { ...day, [a.sid]: [...day[a.sid], a.dishId] } : day));
      return { ...state, menu, published: false };
    }
    case 'REMOVE_FROM_MENU': {
      const menu = state.menu.map((day, i) => (i === a.di ? { ...day, [a.sid]: day[a.sid].filter((_, j) => j !== a.index) } : day));
      return { ...state, menu, published: false };
    }
    case 'TOGGLE_ACK':
      return { ...state, acks: state.acks.includes(a.key) ? state.acks.filter((k) => k !== a.key) : [...state.acks, a.key] };
    case 'PUBLISH':
      return { ...state, published: true, pubBy: a.by };
    case 'RESET':
      return { ...initial(), role: state.role };
    default:
      return state;
  }
}

const Ctx = createContext(null);

export function StoreProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, undefined, load);
  const [toastMsg, setToastMsg] = useState('');
  const [toastOn, setToastOn] = useState(false);
  const timer = useRef();

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch {
      /* ignore */
    }
  }, [state]);

  const toast = useCallback((msg) => {
    setToastMsg(msg);
    setToastOn(true);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setToastOn(false), 3200);
  }, []);

  const value = useMemo(() => {
    const wasPublished = state.published;
    const stale = (msg) => wasPublished && toast(msg);
    return {
      state,
      toast,
      actions: {
        setRole: (role) => dispatch({ type: 'SET_ROLE', role }),
        saveChild: (id, rec) => {
          stale('Saved. Clashes updated. Publish the week again.');
          if (!wasPublished) toast('Saved. Clashes updated across the menu.');
          dispatch({ type: 'SAVE_CHILD', id, rec });
        },
        saveDish: (id, rec) => {
          toast(wasPublished ? 'Dish saved. Publish the week again.' : 'Dish saved. Clashes updated across the menu.');
          dispatch({ type: 'SAVE_DISH', id, rec });
        },
        addToMenu: (di, sid, dishId) => {
          stale('Menu changed. Publish the week again.');
          dispatch({ type: 'ADD_TO_MENU', di, sid, dishId });
        },
        removeFromMenu: (di, sid, index) => {
          stale('Menu changed. Publish the week again.');
          dispatch({ type: 'REMOVE_FROM_MENU', di, sid, index });
        },
        toggleAck: (key) => dispatch({ type: 'TOGGLE_ACK', key }),
        publish: (by) => {
          dispatch({ type: 'PUBLISH', by });
          toast('Week published. Teachers now see it on Today.');
        },
        reset: () => {
          dispatch({ type: 'RESET' });
          toast('Sample data restored.');
        },
      },
    };
  }, [state, toast]);

  return (
    <Ctx.Provider value={value}>
      {children}
      <div id="toast" className={toastOn ? 'show' : ''} role="status" aria-live="polite">
        {toastMsg}
      </div>
    </Ctx.Provider>
  );
}

export const useStore = () => useContext(Ctx);
